SampleMode <-
function(x) {
  x.unique <- unique(x)
  return(x.unique[which.max(tabulate(match(x, x.unique)))])
}
